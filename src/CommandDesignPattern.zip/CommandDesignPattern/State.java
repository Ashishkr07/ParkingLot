package CommandDesignPattern;

public enum State {

    ON,
    OFF
}
