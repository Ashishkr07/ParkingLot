package Stock_Price_Alert_System;

public interface Observer {

    public void update(Stock stock);
}
