package NotificationDispatchSystem_Strategy_Factory;

public interface PrioritySelectStrategy {

    public String select(String notification);
}
