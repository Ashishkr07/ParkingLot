package NotificationDispatchSystem_Strategy_Factory;

public interface NotificationDispatchStrategy {

    public void dispatch(String notification);
}
