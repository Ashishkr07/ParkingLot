package NotificationDispatchSystem_Strategy_Factory;

public enum Channel {

    SMS,
    EMAIL,
    PUSH,
    SLACK
}
