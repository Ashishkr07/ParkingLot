package NotificationDispatchSystem_Strategy_Factory;

public enum Priority {
    NORMAL,
    HIGH,
    SILENT
}
