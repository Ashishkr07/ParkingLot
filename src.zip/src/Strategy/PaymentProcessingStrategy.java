package Strategy;

public interface PaymentProcessingStrategy {

    public void pay(double amount);
}
