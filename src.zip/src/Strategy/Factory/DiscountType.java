package Strategy.Factory;

public enum DiscountType {

    Festival,
    NoDiscount,
    Premium
}
