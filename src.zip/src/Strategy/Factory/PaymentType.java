package Strategy.Factory;

public enum PaymentType {
    CARD,
    WALLET,
    UPI
}
