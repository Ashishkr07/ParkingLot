package ParkingLot;

public interface Vehicle {

    public VehicleType getType();

    public double getCharge();
}
