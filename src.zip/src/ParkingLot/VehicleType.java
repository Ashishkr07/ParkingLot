package ParkingLot;

public enum VehicleType {
    BIKE,
    CAR,
    TRUCK
}
